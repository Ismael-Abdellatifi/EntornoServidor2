package com.example.cv_portfolio;

public class Estudio {
    private String nombre;
    private String centro;
    private String aniosCursados;

    public Estudio(String nombre, String centro, String aniosCursados) {
        this.nombre = nombre;
        this.centro = centro;
        this.aniosCursados = aniosCursados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCentro() {
        return centro;
    }

    public void setCentro(String centro) {
        this.centro = centro;
    }

    public String getAniosCursados() {
        return aniosCursados;
    }

    public void setAniosCursados(String aniosCursados) {
        this.aniosCursados = aniosCursados;
    }

}

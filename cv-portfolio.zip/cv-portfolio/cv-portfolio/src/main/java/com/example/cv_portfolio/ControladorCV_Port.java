package com.example.cv_portfolio;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControladorCV_Port {
@GetMapping("/curriculum")
    private String mostrarCurriculum(Model model){
    Habilidad habilidad = new Habilidad("Ingles", "Bajo");
    model.addAttribute("habilidad", habilidad);
    Estudio estudio = new Estudio("DAW", "IES.VELAZQUEZ", "2026-2027");
    model.addAttribute("estudio", estudio);
    ExperienciaLaboral experencia = new ExperienciaLaboral("Manteca S.L", "Tecnico de mantenimiento", 2);
    model.addAttribute("experienciaLaboral", experencia);

    return "curriculum";
}

}

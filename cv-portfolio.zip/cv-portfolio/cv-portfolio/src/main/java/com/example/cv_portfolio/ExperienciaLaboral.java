package com.example.cv_portfolio;

public class ExperienciaLaboral {
    private String nombreEmpresa;
    private String descripcion;
    private int aniosTrabajados;

    public ExperienciaLaboral(String nombreEmpresa, String descripcion, int aniosTrabajados) {
        this.nombreEmpresa = nombreEmpresa;
        this.descripcion = descripcion;
        this.aniosTrabajados = aniosTrabajados;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getAniosTrabajados() {
        return aniosTrabajados;
    }

    public void setAniosTrabajados(int aniosTrabajados) {
        this.aniosTrabajados = aniosTrabajados;
    }

}
